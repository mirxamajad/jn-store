# laravel-multi-auth
how to create multiple auth (Authentication) in Laravel 7 using middleware.

[Laravel 7 Multi Auth: Create Multi Auth (Authentication) in Laravel](https://www.positronx.io/create-multi-auth-authentication-in-laravel/)
