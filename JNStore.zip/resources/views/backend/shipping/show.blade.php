
<div class="row">
    <div class="col-12">
        <label class="form-label">State:</label>
        {{$shipping->states}}
    </div>
    <div class="col-12">
        <label class="form-label">Charges:</label>
        {{$shipping->charges}}
    </div>


</div>

