<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <!-- start page content-->
   <div class="page-content">

    <!--start breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">All Orders</div>
    </div>
    <!--end breadcrumb-->
          <hr/>
          <?php if(session('status')): ?>
            <div class="alert alert-dismissible fade show py-2 bg-success">
                <div class="d-flex align-items-center">
                  <div class="fs-3 text-white"><ion-icon name="checkmark-circle-sharp"></ion-icon>
                  </div>
                  <div class="ms-3">
                    <div class="text-white"><?php echo e(session('status')); ?></div>
                  </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
        <?php endif; ?>
          <div class="card">
              <div class="card-body">
                  <div class="table-responsive">
                      <table id="example" class="table table-striped table-bordered" style="width:100%">
                          <thead>
                              <tr>
                                  <th>Customer Name</th>
                                  <th>Email</th>
                                  <th>Phone</th>
                                  <th>Address</th>
                                  <th>Amount</th>
                                  
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $checkout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                       <?php echo e($key->name); ?>

                                    </td>
                                    <td><?php echo e($key->email); ?></td>
                                    <td><?php echo e($key->phone); ?></td>
                                    <td><?php echo e($key->address_1); ?> </td>
                                    <td><?php echo e($key->amount); ?></td>
                                    
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
    </div>
    <!-- end page content-->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/order/index.blade.php ENDPATH**/ ?>