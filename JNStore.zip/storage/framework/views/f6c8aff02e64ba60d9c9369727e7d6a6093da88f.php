  <aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
      <div>
        <img src="<?php echo e(asset('admin/images/logo-icon-2.png')); ?>" class="logo-icon" alt="logo icon">
      </div>
      <div>
        <h4 class="logo-text">Dashboard</h4>
      </div>
      <div class="toggle-icon ms-auto">
        <ion-icon name="menu-sharp"></ion-icon>
      </div>
    </div>
    <ul class="metismenu" id="menu">
      <li>
        <a href="<?php echo e(route('admin.route')); ?>" >
          <div class="parent-icon">
            <ion-icon name="home-sharp"></ion-icon>
          </div>
          <div class="menu-title">Dashboard</div>
        </a>
      </li>
      <li class="menu-label">Product Management</li>
      <li>
        <a href="javascript:;" class="has-arrow">
          <div class="parent-icon">
            <ion-icon name="briefcase-sharp"></ion-icon>
          </div>
          <div class="menu-title">Category</div>
        </a>
        <ul>
          <li>
            <a href="<?php echo e(route('catgeory.index')); ?>">
              <ion-icon name="ellipse-outline"></ion-icon>All Categories
            </a>
          </li>
        </ul>
      </li>

      <li>
        <a class="has-arrow" href="javascript:;">
          <div class="parent-icon">
            <ion-icon name="gift-sharp"></ion-icon>
          </div>
          <div class="menu-title">Components</div>
        </a>
        <ul>
          <li> <a href="component-alerts.html">
              <ion-icon name="ellipse-outline"></ion-icon>Alerts
            </a>
          </li>
          <li> <a href="component-accordions.html">
              <ion-icon name="ellipse-outline"></ion-icon>Accordions
            </a>
          </li>
          <li> <a href="component-badges.html">
              <ion-icon name="ellipse-outline"></ion-icon>Badges
            </a>
          </li>
          <li> <a href="component-buttons.html">
              <ion-icon name="ellipse-outline"></ion-icon>Buttons
            </a>
          </li>
          <li> <a href="component-cards.html">
              <ion-icon name="ellipse-outline"></ion-icon>Cards
            </a>
          </li>
          <li> <a href="component-carousels.html">
              <ion-icon name="ellipse-outline"></ion-icon>Carousels
            </a>
          </li>
          <li> <a href="component-list-groups.html">
              <ion-icon name="ellipse-outline"></ion-icon>List Groups
            </a>
          </li>
          <li> <a href="component-media-object.html">
              <ion-icon name="ellipse-outline"></ion-icon>Media Objects
            </a>
          </li>
          <li> <a href="component-modals.html">
              <ion-icon name="ellipse-outline"></ion-icon>Modals
            </a>
          </li>
          <li> <a href="component-navs-tabs.html">
              <ion-icon name="ellipse-outline"></ion-icon>Navs & Tabs
            </a>
          </li>
          <li> <a href="component-paginations.html">
              <ion-icon name="ellipse-outline"></ion-icon>Pagination
            </a>
          </li>
          <li> <a href="component-popovers-tooltips.html">
              <ion-icon name="ellipse-outline"></ion-icon>Popovers & Tooltips
            </a>
          </li>
          <li> <a href="component-progress-bars.html">
              <ion-icon name="ellipse-outline"></ion-icon>Progress
            </a>
          </li>
          <li> <a href="component-spinners.html">
              <ion-icon name="ellipse-outline"></ion-icon>Spinners
            </a>
          </li>
          <li> <a href="component-notifications.html">
              <ion-icon name="ellipse-outline"></ion-icon>Notifications
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a class="has-arrow" href="javascript:;">
          <div class="parent-icon">
            <ion-icon name="leaf-sharp"></ion-icon>
          </div>
          <div class="menu-title">Icons</div>
        </a>
        <ul>
          <li> <a href="icons-line-icons.html">
              <ion-icon name="ellipse-outline"></ion-icon>Line Icons
            </a>
          </li>
          <li> <a href="icons-boxicons.html">
              <ion-icon name="ellipse-outline"></ion-icon>Boxicons
            </a>
          </li>
          <li> <a href="icons-feather-icons.html">
              <ion-icon name="ellipse-outline"></ion-icon>Feather Icons
            </a>
          </li>
        </ul>
      </li>
      <li class="menu-label">Forms & Tables</li>
      <li>
        <a class="has-arrow" href="javascript:;">
          <div class="parent-icon">
            <ion-icon name="newspaper-sharp"></ion-icon>
          </div>
          <div class="menu-title">Forms</div>
        </a>
        <ul>
          <li> <a href="form-elements.html">
              <ion-icon name="ellipse-outline"></ion-icon>Form Elements
            </a>
          </li>
          <li> <a href="form-input-group.html">
              <ion-icon name="ellipse-outline"></ion-icon>Input Groups
            </a>
          </li>
          <li> <a href="form-layouts.html">
              <ion-icon name="ellipse-outline"></ion-icon>Forms Layouts
            </a>
          </li>
          <li> <a href="form-validations.html">
              <ion-icon name="ellipse-outline"></ion-icon>Form Validation
            </a>
          </li>
          <li> <a href="form-date-time-pickes.html">
              <ion-icon name="ellipse-outline"></ion-icon>Date Pickers
            </a>
          </li>
          <li> <a href="form-select2.html">
              <ion-icon name="ellipse-outline"></ion-icon>Select2
            </a>
          </li>
        </ul>
      </li>
      <li>
        <a class="has-arrow" href="javascript:;">
          <div class="parent-icon">
            <ion-icon name="server-sharp"></ion-icon>
          </div>
          <div class="menu-title">Tables</div>
        </a>
        <ul>
          <li> <a href="table-basic-table.html">
              <ion-icon name="ellipse-outline"></ion-icon>Basic Table
            </a>
          </li>
          <li> <a href="table-advance-tables.html">
              <ion-icon name="ellipse-outline"></ion-icon>Advance Tables
            </a>
          </li>
          <li> <a href="table-datatable.html">
              <ion-icon name="ellipse-outline"></ion-icon>Data Table
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </aside>
<header class="top-header">
    <nav class="navbar navbar-expand gap-3">
        <div class="mobile-menu-button">
        <ion-icon name="menu-sharp"></ion-icon>
        </div>
        <div class="top-navbar-right ms-auto">
        <ul class="navbar-nav align-items-center">
            <li class="nav-item mobile-search-button">
            <a class="nav-link" href="javascript:;">
                <div class="">
                <ion-icon name="search-sharp"></ion-icon>
                </div>
            </a>
            </li>
            <li class="nav-item">
            <a class="nav-link dark-mode-icon" href="javascript:;">
                <div class="mode-icon">
                <ion-icon name="moon-sharp"></ion-icon>
                </div>
            </a>
            </li>
            <li class="nav-item dropdown dropdown-user-setting">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="javascript:;" data-bs-toggle="dropdown">
                <div class="user-setting">
                <img src="<?php echo e(asset('admin/images/avatars/06.png')); ?>" class="user-img" alt="">
                </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                <a class="dropdown-item" href="javascript:;">
                    <div class="d-flex flex-row align-items-center gap-2">
                    <img src="<?php echo e(asset('admin/images/avatars/06.png')); ?>" alt="" class="rounded-circle" width="54" height="54">
                    <div class="">
                        <h6 class="mb-0 dropdown-user-name"><?php echo e(Auth::user()->name); ?></h6>
                    </div>
                    </div>
                </a>
                </li>
                <li>
                <hr class="dropdown-divider">
                </li>
                <li>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <div class="d-flex align-items-center">
                    <div class="">
                        <ion-icon name="log-out-outline"></ion-icon>
                    </div>
                    <div class="ms-3"><span>Logout</span></div>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    </div>
                </a>
                </li>
            </ul>
            </li>

        </ul>

        </div>
    </nav>
</header>
<?php /**PATH C:\Users\MiRzA\Desktop\JNStore\resources\views/layouts/parts/navbar.blade.php ENDPATH**/ ?>