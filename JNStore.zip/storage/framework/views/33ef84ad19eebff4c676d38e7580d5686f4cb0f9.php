<?php $__env->startSection('contant'); ?>
<div class="checkout_area pt-80">
    <div class="container">
        <div class="row">
            <?php $total = 0 ?>
                <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total += $details['price'] * $details['quantity'] ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-7 col-lg-7 col-md-12">
                <div class="checkout_form mb-100">
                    <form action="<?php echo e(route('checkout.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="checkout__wrap col-6">
                                <label>User Name <span>*</span></label>
                                <input type="text" required name="name" >
                            </div>
                            <div class="checkout__wrap col-6">
                                <label>Phone <span>*</span></label>
                                <input type="text" required name="phone">
                            </div>
                            <div class="checkout__wrap col-6">
                                <label>Email address <span>*</span></label>
                                <input type="email" required name="email">
                            </div>
                            <div class="checkout__wrap col-6">
                                <input type="hidden" value="<?php echo e($total); ?>" required name="amount">
                                <label>Country / Region <span>*</span></label>
                                <select required name="country">
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Arab">Arab</option>
                                    <option value="America">America</option>
                                    <option value="Saudi">Saudi Arabia</option>
                                    <option value="Israil">Israil</option>
                                    <option value="Irak">Irak</option>
                                    <option value="Netherland">Netherland</option>
                                </select>
                            </div>
                            <div class="checkout__wrap col-6">
                                <label>Town / City *<span></span></label>
                                <input type="text" required name="town">
                            </div>
                            <div class="checkout__wrap col-6">
                                <label>Postcode<span>*</span></label>
                                <input type="text" required name="postcode">
                            </div>
                            <div class="checkout__wrap">
                                <label>Street address <span>*</span></label>
                                <input class="mb-20" type="text" required name="address_1" placeholder="house number and street number">
                                <input type="text"  name="address_2" placeholder="apartment,suite,unit,etc.(optional)">
                            </div>
                            
                            <div class="checkout__accordion mt-30 mb-20">
                                <h4>
                                    Payment Method
                                </h4>
                                <div class="accordion  row" id="accordionExample">
                                    <div class="accordion-item col-2">
                                        <label class="form-label btn btn-primary btn-lg" >Stripe
                                            <input class="" type="radio"  name="paymentmethod" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        </label>
                                    </div>
                                    <div class="accordion-item col-4">
                                        <label class="form-label btn btn-primary btn-lg"> Cash on delivery
                                            <input class="cod" type="radio" name="paymentmethod" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="ture" aria-controls="collapseThree">
                                        </label>

                                    </div>
                                </div>
                            </div>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="form-row" id="payment-element">
                                        <label for="form-label card-element">
                                        Credit or debit card
                                        </label>
                                        <div id="card-element"  style="margin-top: 10px;border: 1px solid;border-radius: 5px;padding: 13px;">
                                        <!-- A Stripe Element will be inserted here. -->
                                        </div>
                                        <!-- Used to display Element errors. -->
                                        <div id="card-errors" role="alert"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="order-button" style="margin-top: 10px">
                                <button type="submit">place order</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-xl-5 col-lg-5 col-md-12">
                <div class="cart__acount ml-50">
                    <h5>Your order</h5>
                  <table>
                      <tr class="first-child-2">
                          <td>Order</td>
                          <td>
                            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="add_cart_product">
                                <div class="add_cart_product__thumb">
                                    <img src="<?php echo e(asset('product/'.$details['image'][0]['name'])); ?>" alt="">
                                </div>
                                <div class="add_cart_product__content">
                                    <h5><?php echo e($details['name']); ?></h5>
                                    <p><?php echo e($details['quantity']); ?> × $<?php echo e($details['price']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </td>
                      </tr>
                      <tr class="first-child-2">
                          <td>Subtotal</td>

                          <td class="lightbluee">$<?php echo e($total); ?></td>
                      </tr>
                      
                  </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.cod').click(function() {
        if($('.cod').is(':checked')) {
            $('#collapseThree').removeClass('show');

         }
    });
    var stripe = Stripe('pk_test_n78Z2CBbdPImb7bRVVMkJCxF00TYyPoenv');
    var elements = stripe.elements();
    var style = {
        base: {
            fontSize: '16px',
            color: '#32325d',
        },
    };
    var card = elements.create('card', {style: style});
    card.mount('#card-element');
    var form = document.getElementById('payment-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        stripe.createToken(card).then(function(result) {
            if (result.error) {
                var errorElement = document.getElementById('card-errors');
                errorElement.textContent = result.error.message;
            } else {
                stripeTokenHandler(result.token);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<style>
.hidden {
  display: none;
}

#payment-message {
  color: rgb(105, 115, 134);
  font-size: 16px;
  line-height: 20px;
  padding-top: 12px;
  text-align: center;
}

#payment-element {
  margin-bottom: 24px;
}

/* Buttons and links */
button {
  background: #5469d4;
  font-family: Arial, sans-serif;
  color: #ffffff;
  border-radius: 4px;
  border: 0;
  padding: 12px 16px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  display: block;
  transition: all 0.2s ease;
  box-shadow: 0px 4px 5.5px 0px rgba(0, 0, 0, 0.07);
  width: 100%;
}
button:hover {
  filter: contrast(115%);
}
button:disabled {
  opacity: 0.5;
  cursor: default;
}

/* spinner/processing state, errors */
.spinner,
.spinner:before,
.spinner:after {
  border-radius: 50%;
}
.spinner {
  color: #ffffff;
  font-size: 22px;
  text-indent: -99999px;
  margin: 0px auto;
  position: relative;
  width: 20px;
  height: 20px;
  box-shadow: inset 0 0 0 2px;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
.spinner:before,
.spinner:after {
  position: absolute;
  content: "";
}
.spinner:before {
  width: 10.4px;
  height: 20.4px;
  background: #5469d4;
  border-radius: 20.4px 0 0 20.4px;
  top: -0.2px;
  left: -0.2px;
  -webkit-transform-origin: 10.4px 10.2px;
  transform-origin: 10.4px 10.2px;
  -webkit-animation: loading 2s infinite ease 1.5s;
  animation: loading 2s infinite ease 1.5s;
}
.spinner:after {
  width: 10.4px;
  height: 10.2px;
  background: #5469d4;
  border-radius: 0 10.2px 10.2px 0;
  top: -0.1px;
  left: 10.2px;
  -webkit-transform-origin: 0px 10.2px;
  transform-origin: 0px 10.2px;
  -webkit-animation: loading 2s infinite ease;
  animation: loading 2s infinite ease;
}

@-webkit-keyframes loading {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes  loading {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

@media  only screen and (max-width: 600px) {
  form {
    width: 80vw;
    min-width: initial;
  }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/frontend/parts/checkout.blade.php ENDPATH**/ ?>