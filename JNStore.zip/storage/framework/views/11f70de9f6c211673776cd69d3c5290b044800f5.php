<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <!-- start page content-->
   <div class="page-content">

    <!--start breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Categories</div>
      <div class="ps-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb mb-0 p-0 align-items-center">
            <li class="breadcrumb-item"><a href="javascript:;"><ion-icon name="home-outline"></ion-icon></a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Category</li>
          </ol>
        </nav>
      </div>
    </div>
    <!--end breadcrumb-->

        <div class="row">
            <div class="col-6">
                <h6 class="mb-0 text-uppercase">DataTable Example</h6>
            </div>
            <div class="col-6 d-flex flex-row-reverse ">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#create">Create Category</button>
                <div class="modal fade" id="create" tabindex="-1" aria-labelledby="createLabel" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="createLabel">Add New Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form class="form-body categoryForm row g-3" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="col-12">
                                    <label class="form-lable">Name</label>
                                    <input type="text" name="name" id="name" required placeholder="Category Name" class="form-control">
                                </div>
                                <div class="col-12">
                                    <label class="form-lable">Slug</label>
                                    <input type="text" name="slug" id="slug" required placeholder=""  class="form-control">
                                </div>
                                <div class="col-12">
                                    <label class="form-lable">Add Icon Image</label>
                                    <input type="file" name="icon" id="icon" required class="form-control">
                                </div>
                                <div class="col">
                                    <button type="submit" class="btn categoryBtn btn-primary">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <hr/>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Icon</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><img src="<?php echo e(asset('CategoryIcon/'.$category->image)); ?>" width="100px" alt=" NO Image found"></td>
                                    <td>
                                        <a class="btn btn-success viewBtn" data-url="<?php echo e(route('catgeory.show', $category->id)); ?>" data-bs-toggle="modal" data-bs-target="#view"  href="javascript:void(0)">
                                            View
                                        </a>
                                        <a class="btn btn-primary editBtn" data-url="<?php echo e(route('catgeory.edit', $category->id)); ?>" href="javascript:void(0)">
                                            Edit
                                        </a>
                                        <form action="<?php echo e(route('catgeory.destroy', $category->id)); ?>" method="POST" onsubmit="return confirm();" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="Delete">
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="view" tabindex="-1" aria-labelledby="createLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="createLabel">Show Category</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body getView">

            </div>
        </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#name').change(function (e) {
        let name = $('#name').val()
        let str = name.replace(/\s+/g, '-').toLowerCase();
        $('#slug').val(str)
    });
    $('.categoryForm').submit(function (e) {
        e.preventDefault();
        let formData = new FormData($('.categoryForm')[0]);
       $.ajax({
            type: "POSt",
            url: "<?php echo e(route('catgeory.store')); ?>",
            data: formData,
            processData: false,
            contentType: false,
           success: function (response) {
            $('#create').modal('hide');
            $('#catrgoryFrom').remove();
            success_noti(response)
           }
       });

    });
$("body").on("click",".viewBtn", function(){
let url = $(this).data('url');
$.ajax({
    url: url,
    _method: 'GET',
    success: function(respose) {
       $('.getView').append(respose);
    }
  });
});


$("body").on("click",".deleteBtn", function(){
let url = $(this).data('url');
 console.log(url);
 debugger;
if (confirm('Do You Want To delete')) {
    $.ajax({
    url: url,
    _method: 'DELETE',
    success: function(respose) {
        // round_error_noti()
    }
  });
}


});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MiRzA\Desktop\JNStore\resources\views/backend/category/index.blade.php ENDPATH**/ ?>