<header class="header-area">
    <div class="gota_top bg-soft d-none d-sm-block">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                    <div class="gota_lang">
                        <ul>
                            <li>
                                <a href="tel:888-5555-5555">Tel:888-5555-5555</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-4 offset-xl-5 col-lg-6 col-md-6 col-sm-6 text-end">
                    <div class="gota_right">
                        <ul>
                            <li><a href="<?php echo e(route('checkout.index')); ?>">Checkout</a></li>
                            <?php if(empty(Auth::user()->name)): ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>">
                                        Login & register
                                    </a>
                                </li>
                            <?php else: ?>
                                <?php if(Auth::user()->is_admin==1): ?>
                                    <li>
                                        <a href="<?php echo e(route('admin.route')); ?>">
                                            Dashboard
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e(route('home')); ?>">
                                            Profile
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();">

                                            <div class="ms-3"><span>Logout</span></div>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="gota_bottom position-relative">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 d-none d-sm-block">
                    <div class="gota_search">
                        <form class="search_form">
                            <button class="search_action"><i
                                    class="fal fa-search d-sm-none d-md-block"></i></button>
                            <input type="text" placeholder="search" />
                        </form>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-8 col-md-4 col-sm-4">
                    <div class="sidemenu sidemenu-1 d-lg-none d-md-block">
                        <a class="open" href="#"><i class="fal fa-bars"></i></a>
                    </div>
                    <div class="main-menu">
                        <nav id="mobile-menu">
                            <ul>

                                <li class=""><a href="<?php echo e(url('',)); ?>">Home </a></li>
                                <li class="position-static menu-item-has-children"><a href="<?php echo e(route('index.allproduct', ['id'=>$category[0]['id'] , 'slug'=> $category[0]['slug'], ] )); ?>"><?php echo e($category[0]['name']); ?></a>
                                    <ul class="mega_menu" data-background="<?php echo e(asset('customer/img/mega-menu/product.jpg')); ?>">
                                        <li>
                                            <?php
                                                $count=0
                                            ?>
                                                <h4 class="mega_title">
                                                    <a href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[0]['slug'],'id'=>$subcategory[0]['id'] , 'slug'=> $subcategory[0]['slug'], ])); ?>" class="mega_title"><?php echo e($subcategory[0]['name']); ?></a>
                                                </h4>
                                                <ul class="mega_item">

                                                    <?php $__currentLoopData = $men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[0]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>">
                                                                <?php echo e($key->name); ?>

                                                            </a>
                                                        </li>
                                                        <?php if($count<5): ?>
                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                        <?php
                                                            $count++
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                        </li>
                                        <li>
                                            <?php
                                                $count=0
                                            ?>
                                                <h4 class="mega_title">
                                                    <a href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[0]['slug'],'id'=>$subcategory[1]['id'] , 'slug'=> $subcategory[1]['slug'], ])); ?>" class="mega_title"><?php echo e($subcategory[1]['name']); ?></a>
                                                </h4>
                                                <ul class="mega_item">

                                                    <?php $__currentLoopData = $women; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[1]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>">
                                                                <?php echo e($key->name); ?>

                                                            </a>
                                                        </li>
                                                        <?php if($count<5): ?>
                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                        <?php
                                                            $count++
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                        </li>
                                        <li>
                                            <?php
                                                $count=0
                                            ?>
                                                <h4 class="mega_title">
                                                    <a  href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[0]['slug'],'id'=>$subcategory[2]['id'] , 'slug'=> $subcategory[2]['slug'], ])); ?>" class="mega_title"><?php echo e($subcategory[2]['name']); ?></a>
                                                </h4>
                                                <ul class="mega_item">

                                                    <?php $__currentLoopData = $kids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[2]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>">
                                                                <?php echo e($key->name); ?>

                                                            </a>
                                                        </li>
                                                        <?php if($count<5): ?>
                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                        <?php
                                                            $count++
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                        </li>
                                        <li>

                                        </li>
                                    </ul>
                                </li>
                                <li class="position-static menu-item-has-children"><a href="<?php echo e(route('index.allproduct', ['id'=>$category[1]['id'] , 'slug'=> $category[1]['slug'], ] )); ?>"><?php echo e($category[1]['name']); ?></a>
                                    <ul class="mega_menu_2">
                                        <li data-background="<?php echo e(asset('customer/img/mega-menu/product2.jpg')); ?>">
                                            <h4 class="mega_title_2">
                                                <a href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[1]['slug'],'id'=>$subcategory[3]['id'] , 'slug'=> $subcategory[3]['slug'], ])); ?>" class="mega_title_2"><?php echo e($subcategory[3]['name']); ?></a>
                                            </h4>
                                            <ul class="mega_item_2">
                                                <?php $__currentLoopData = $fragrance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[3]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>">
                                                            <?php echo e($key->name); ?>

                                                        </a>
                                                    </li>
                                                    <?php if($count<5): ?>
                                                        <?php break; ?>
                                                    <?php endif; ?>
                                                    <?php
                                                        $count++
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        <li data-background="<?php echo e(asset('customer/img/mega-menu/product3.jpg')); ?>">
                                            <h4 class="mega_title_2">
                                                <a href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[1]['slug'],'id'=>$subcategory[4]['id'] , 'slug'=> $subcategory[4]['slug'], ])); ?>"><?php echo e($subcategory[4]['name']); ?></a>
                                            </h4>
                                            <ul class="mega_item_2">
                                                <?php $__currentLoopData = $jewelery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[4]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>l">
                                                            <?php echo e($key->name); ?>

                                                        </a>
                                                    </li>
                                                    <?php if($count<5): ?>
                                                        <?php break; ?>
                                                    <?php endif; ?>
                                                    <?php
                                                        $count++
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        <li data-background="<?php echo e(asset('customer/img/mega-menu/product4.jpg')); ?>">
                                            <h4 class="mega_title_2">
                                                <a href="<?php echo e(route('index.allsubproduct', ['cat'=>$category[1]['slug'],'id'=>$subcategory[5]['id'] , 'slug'=> $subcategory[5]['slug'], ])); ?>" class="mega_title_2"><?php echo e($subcategory[5]['name']); ?></a>
                                            </h4>
                                            <ul class="mega_item_2">
                                                <?php $__currentLoopData = $makeups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('index.allchildproduct', ['subcate'=>$subcategory[5]['slug'],'id'=>$key->id,'slug'=>$key->slug])); ?>">
                                                            <?php echo e($key->name); ?>

                                                        </a>
                                                    </li>
                                                    <?php if($count<5): ?>
                                                        <?php break; ?>
                                                    <?php endif; ?>
                                                    <?php
                                                        $count++
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        
                                    </ul>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('index.allproduct', ['id'=>$category[2]['id'] , 'slug'=> $category[2]['slug'], ] )); ?>">
                                        <?php echo e($category[2]['name']); ?>

                                    </a>
                                </li>
                                <li>
                                    <a class="d-none d-xl-block" href="<?php echo e(url('')); ?>">
                                        <img class="pl-10 pr-10" width="75%" src="<?php echo e(asset('customer/img/logo/jnstore.png')); ?>" alt="">
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('index.allproduct', ['id'=>$category[3]['id'] , 'slug'=> $category[3]['slug'], ] )); ?>">
                                        <?php echo e($category[3]['name']); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('index.allproduct', ['id'=>$category[4]['id'] , 'slug'=> $category[4]['slug'], ] )); ?>">
                                        <?php echo e($category[4]['name']); ?>

                                    </a>
                                </li>
                                <li >
                                    <a href="<?php echo e(route('index.allproduct', ['id'=>$category[6]['id'] , 'slug'=> $category[6]['slug'], ] )); ?>">
                                        <?php echo e($category[6]['name']); ?>

                                    </a>

                                </li>
                                <li class="menu-item-has-children"><a href="about.html">Company</a>
                                    <ul class="sub-menu">
                                        <li><a href="#">about us</a></li>
                                        <li><a href="#">contact</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>

                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4">
                    <div class="gota_cart gotat_cart_1 text-end">
                        <a href="javascript:void(0)">
                            <i class="fal fa-shopping-cart"></i>My Cart
                            <span class="counter" id="counter">
                                <?php if(session('cart')): ?>
                                    <?php echo e(count((array) session('cart'))); ?>

                                <?php endif; ?>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/frontend/parts/header.blade.php ENDPATH**/ ?>