<?php $__env->startSection('contant'); ?>
    <!-- gallary area start -->
    <div class="about__gallary service_page" data-background="<?php echo e(asset('customer/img/about/about-2.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-4 col-md-4 offset-xl-1">
                    <div class="service-single">
                        <h3 class="mb-30">we are on our way</h3>
                        <p class="mb-40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin <br> iaculis luctus leo ut lacinia. Nunc et augue pulvinar, luctus <br> mi non, sagittis odio. Phasellus congue sem nulla, non <br> sodales orci malesuada vel. Aliquam posuere mi eros, at <br> condimentum elit feugiat vel.</p>
                        <a href="service.html">read more</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- gallary area end -->

    <!-- service area start  -->
    <div class="m_service__area mb-100">
        <div class="container">
            <div class="service__wrapper text-center pt-100">
                <h2>our services</h2>
            </div>
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-4 offset-xl-1">
                    <div class="m_single_service pt-80">
                        <div class="m_single_service__thumb">
                            <img src="<?php echo e(asset('customer/img/service/SEVICES_1-1.png')); ?>" alt="">
                        </div>
                        <div class="m_single_service__content">
                            <h5>PACKING</h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. Phasellus congue sem nulla.non sodales orci malesu da vel. Aliquam mi eros. </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4">
                    <div class="m_single_service pt-80">
                        <div class="m_single_service__thumb">
                            <img src="<?php echo e(asset('customer/img/service/SERVICES_2-1.png')); ?>" alt="">
                        </div>
                        <div class="m_single_service__content">
                            <h5>MOVING</h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. Phasellus congue sem nulla.non sodales orci malesu da vel. Aliquam mi eros. </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4">
                    <div class="m_single_service pt-80">
                        <div class="m_single_service__thumb">
                            <img src="<?php echo e(asset('customer/img/service/SERVICES_3-1.png')); ?>" alt="">
                        </div>
                        <div class="m_single_service__content">
                            <h5>sTORAGE</h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. Phasellus congue sem nulla.non sodales orci malesu da vel. Aliquam mi eros. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- service area end  -->

    <!-- expert area start  -->
    <div class="expert__area mb-130">
        <div class="container">
            <div class="service__wrapper text-center mb-50">
                <h2>our expertise</h2>
            </div>
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-5 offset-xl-1">
                    <div class="expert__thumb">
                        <img src="<?php echo e(('customer/img/service/expertise-1.jpg')); ?>" alt="">
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 pl-50">
                    <div class="expertsingle mb-60 pt-30">
                        <div class="expertsingle__thumb">
                            <span><i class="fal fa-car"></i></span>
                        </div>
                        <div class="expertsingle__content">
                            <h5>Fast delivery </h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. <br> Phasellus congue sem nulla.non orci malesu da vel. <br> Aliquam posuere mi eros.</p>
                        </div>
                    </div>
                    <div class="expertsingle mb-60">
                        <div class="expertsingle__thumb expertsingle__content">
                            <h5>item inspection </h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. <br> Phasellus congue sem nulla.non orci malesu da vel. <br> Aliquam posuere mi eros.</p>
                        </div>
                        <div class="expertsingle__content expertsingle__thumb">
                            <span><i class="fal fa-people-carry"></i></span>
                        </div>
                    </div>
                    <div class="expertsingle ">
                        <div class="expertsingle__thumb">
                            <span><i class="fal fa-box"></i></span>
                        </div>
                        <div class="expertsingle__content">
                            <h5>boxing service</h5>
                            <p>Nunc et augue pulvinar, luctus mi non, sagittis odio. <br> Phasellus congue sem nulla.non orci malesu da vel. <br> Aliquam posuere mi eros.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content" id="myTabCffontent">
        <div class="tab-pane fade show active" id="Description" role="tabpanel" >
        <div class="single_product_description text-center pt-80">
            
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12">
                    <div class="desc__imag_2">
                        <img src="<?php echo e(asset('customer/img/desc/images-d1.jpg')); ?>" alt="">
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 pl-50">
                    <div class="desc_title_wrapper pt-100">
                        <h4>COMFORTABLE TO USE</h4>
                        <h2>QUICKEN YOUR TEMPO PACE</h2>
                    </div>
                    <div class="desc_image_content pt-30 mb-30">
                        <div class="desc-3_image">
                            <img src="<?php echo e(asset('customer/img/desc/d1.jpg')); ?>" alt="">
                        </div>
                        <div class="desc-3_content">
                            <h4>Contrary to popular belief</h4>
                            <p>The gently rounded top together with the back and seat offers a variety of <br> comfortable seating positions, ideal for both long.</p>
                        </div>
                    </div>
                    <div class="desc_image_content mb-30">
                        <div class="desc-3_image">
                            <img src="<?php echo e(asset('customer/img/desc/d2.jpg')); ?>" alt="">
                        </div>
                        <div class="desc-3_content">
                            <h4>Lorem Ipsum is not simply </h4>
                            <p>The gently rounded top together with the back and seat offers a variety of <br> comfortable seating positions, ideal for both long.</p>
                        </div>
                    </div>
                    <div class="desc_image_content mb-30">
                        <div class="desc-3_image">
                            <img src="<?php echo e(asset('customer/img/desc/d3.jpg')); ?>" alt="">
                        </div>
                        <div class="desc-3_content">
                            <h4>If you are going to use</h4>
                            <p>The gently rounded top together with the back and seat offers a variety of <br> comfortable seating positions, ideal for both long.</p>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

    </div>
    <!-- expert area end  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/frontend/app.blade.php ENDPATH**/ ?>