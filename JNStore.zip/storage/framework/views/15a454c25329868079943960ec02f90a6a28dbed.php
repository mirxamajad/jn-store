<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <h6 class="mb-0 text-uppercase">Add New Variant</h6>
        <hr/>
        <div class="card">
            <div class="card-body">
            <div class="p-4 border rounded">
                <form action="<?php echo e(route('productvariant.update', $proVari->id)); ?>" method="POST" class="row g-3 createFrom" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-12 select2-sm">
                        <label class="form-label">Select Product</label>
                        <select  class="multiple-select" data-placeholder="Select Product" name="product" id="mainproduct">
                            <option></option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>" <?php if($product->id == $proVari->product_id): ?>
                                    <?php echo e('selected'); ?>

                                <?php endif; ?>><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <hr>
                    <div class="col-3 select2-sm">
                        <label class="form-label">Status</label>
                        <select name="status" id="status" class="form-control select2">
                            <option value="active" <?php if($proVari->product_id = 'active'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?>>Active</option>
                            <option value="inactive" <?php if($proVari->product_id = 'inactive'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-3 select2-sm sizes">
                        <label class="form-label">Size</label>
                        <select name="size" id="size" class="form-control">
                            <option <?php if($proVari->size = 'xs'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="xs">Extra Small</option>
                            <option <?php if($proVari->size = 's'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="s">Small</option>
                            <option <?php if($proVari->size = 'm'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="m">Medium</option>
                            <option <?php if($proVari->size = 'l'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="l">Large</option>
                            <option <?php if($proVari->size = 'xl'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="xl">Extra Large</option>
                            <option <?php if($proVari->size = 'xxl'): ?>
                                <?php echo e('selected'); ?>

                            <?php endif; ?> value="xxl">X X Large</option>
                        </select>
                    </div>
                    <div class="col-3 select2-sm colors">
                        <label class="form-label">Color</label>
                        <input type="color" class="form-control" name="color" value="<?php echo e($proVari->color); ?>" id="color">
                    </div>
                    <div class="col-3">
                        <label class="form-label">Quntity</label>
                        <input type="text" class="form-control" name="quntity" value="<?php echo e($proVari->quntity); ?>" id="quntity">
                    </div>
                    <div class="col-12">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary createCategory"> Update</button>
                        </div>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/variants/edit.blade.php ENDPATH**/ ?>