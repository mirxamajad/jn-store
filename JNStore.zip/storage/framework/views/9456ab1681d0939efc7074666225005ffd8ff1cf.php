<div class="cart__sidebar cartData">
    <div class="container">
        <div class="cart__content">
            <div class="cart-text">
                <h3 class="mb-40">Shopping cart</h3>
                <?php if(!empty(session('cart'))): ?>
                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="add_cart_product">
                            <div class="add_cart_product__thumb">
                                <img src="<?php echo e(asset('product/'.$details['image'][0]['name'])); ?>" alt="">
                            </div>
                            <div class="add_cart_product__content">
                                <h5><?php echo e($details['name']); ?></h5>
                                <p><?php echo e($details['quantity']); ?> × $<?php echo e($details['price']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="cart-bottom">
                <div class="cart-bottom__text">
                    <span>Subtotal:</span>
                    <?php $total = 0 ?>
                    <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $total += $details['price'] * $details['quantity'] ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="end">
                        <?php if($total!=0): ?>

                            <?php echo e($total); ?>

                        <?php endif; ?>
                    </span>
                    <a href="<?php echo e(route('cart')); ?>">view cart</a>
                    <a href="<?php echo e(route('checkout.index')); ?>">checkout</a>
                </div>
            </div>
                <div class="cart-icon" >
                    <i class="fal fa-times" onclick="CartClose()"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/frontend/parts/cart.blade.php ENDPATH**/ ?>