
<div class="row">
    <div class="col-12">
        <label class="form-label">State:</label>
        <?php echo e($shipping->states); ?>

    </div>
    <div class="col-12">
        <label class="form-label">Charges:</label>
        <?php echo e($shipping->charges); ?>

    </div>


</div>

<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/shipping/show.blade.php ENDPATH**/ ?>