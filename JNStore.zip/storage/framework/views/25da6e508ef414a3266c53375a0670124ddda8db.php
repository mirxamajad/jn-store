
<div class="row">
    <div class="col-12">
        <label class="form-label">Category Name :</label>
        <?php echo e($category->name); ?>



    </div>
    <div class="col-12">
        <label class="form-label">Category Slug :</label>

            <?php echo e($category->slug); ?>



    </div>
    <div class="col-12">
        <label class="form-label">Category Image :</label>
        <br>
        <img src="<?php echo e(asset('ChildCategoryIcon/'.$category->icon)); ?>"  width="150px" alt="Image Not Found ">
    </div>


</div>

<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/chlidcategory/show.blade.php ENDPATH**/ ?>