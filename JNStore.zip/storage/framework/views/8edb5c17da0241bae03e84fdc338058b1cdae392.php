<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Shipping Charges Edit</h5>
                <form class="form-body row g-3" action="<?php echo e(route('shipping.update', $shipping->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-12">
                        <label class="form-lable">State</label>
                        <input type="text" name="states" id="editname" value="<?php echo e($shipping->states); ?>" required placeholder="Category Name" class="form-control">
                    </div>
                    <div class="col-12">
                        <label class="form-lable">Charges</label>
                        <input type="text" name="charges" id="editslug" required placeholder="" value="<?php echo e($shipping->charges); ?>" class="form-control">
                    </div>

                    <div class="col">
                        <button type="submit" class="btn categoryEditBtn btn-primary">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$('#editname').change(function (e) {
    let name = $('#eidtname').val()
    let str = name.replace(/\s+/g, '-').toLowerCase();
    $('#editslug').val(str)
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/shipping/edit.blade.php ENDPATH**/ ?>