<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
    <!-- start page content-->
   <div class="page-content">

    <!--start breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Variant</div>
    </div>
    <!--end breadcrumb-->


        <div class="row">
            <div class="col-6">
                <h6 class="mb-0 text-uppercase">All Variants</h6>
            </div>
            <div class="col-6 d-flex flex-row-reverse">
                <a href="<?php echo e(route('productvariant.create')); ?>" type="button" class="btn btn-primary" >New Variant</a>
            </div>
        </div>
        <br>
          <hr/>
          <?php if(session('status')): ?>
            <div class="alert alert-dismissible fade show py-2 bg-success">
                <div class="d-flex align-items-center">
                  <div class="fs-3 text-white"><ion-icon name="checkmark-circle-sharp"></ion-icon>
                  </div>
                  <div class="ms-3">
                    <div class="text-white"><?php echo e(session('status')); ?></div>
                  </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
        <?php endif; ?>
          <div class="card">
              <div class="card-body">
                  <div class="table-responsive">
                      <table id="example" class="table table-striped table-bordered" style="width:100%">
                          <thead>
                              <tr>
                                  <th>Product Name</th>
                                  <th>Status</th>
                                  <th>Size</th>
                                  <th>Color</th>
                                  <th>Quantity</th>
                                  <th>Action</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $vari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                       <?php echo e($key->product['name']); ?>

                                    </td>
                                    <td><?php echo e($key->status); ?></td>
                                    <td><?php echo e($key->size); ?></td>
                                    <td> <span style="background: <?php echo e($key->color); ?>;border-radius:5px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        </td>
                                    <td><?php echo e($key->quntity); ?></td>
                                    <td>
                                        
                                        <a href="<?php echo e(route('productvariant.edit',$key->id)); ?>" class="btn btn-success"> Edit </a>
                                        <form action="<?php echo e(route('productvariant.destroy', $key->id)); ?>" method="POST" onsubmit="return confirm();" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="Delete">
                                        </form>
                                    </td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
    </div>
    <!-- end page content-->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/backend/variants/index.blade.php ENDPATH**/ ?>