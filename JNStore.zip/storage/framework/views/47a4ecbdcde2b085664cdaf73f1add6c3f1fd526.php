<div class="view-background">
    <div class="row">
        <div class="col-xl-5 col-lg-5 col-md-5">
            <div class="quickview">
                <div class="quickview__thumb">
                    <?php for($i=0;$i<count($product->image); $i++): ?>
                        <?php if($i == 0): ?>
                            <img src="<?php echo e(asset('product/'.$product->image[$i]['name'])); ?>" alt="product_image">
                        <?php else: ?>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <div class="col-xl-7 col-lg-7 col-md-7">
            <div class="viewcontent">
                <div class="viewcontent__header">
                    <h2><?php echo e($product->name); ?></h2>
                    <button class="view_close product-p-close" onclick="closePop()">
                        <i class="fal fa-times-circle"></i>
                    </button>
                </div>
                <div class="viewcontent__rating">
                    <i class="fal fa-star ratingcolor"></i>
                    <i class="fal fa-star ratingcolor"></i>
                    <i class="fal fa-star ratingcolor"></i>
                    <i class="fal fa-star"></i>
                </div>
                <div class="viewcontent__price">
                    <h4><span>$</span><?php echo e($product->price); ?></h4>
                </div>
                <div class="viewcontent__stock">
                    <h4>Available :<span> In stock</span></h4>
                </div>
                <div class="viewcontent__details">
                    <p><?php echo e($product->summary); ?></p>
                </div>
                <div class="viewcontent__action">
                    <span><button class="btn btn-default addToCart" data-id="<?php echo e(route('add.to.cart', $product->id)); ?>">add to cart</button></span>
                    
                </div>
                <div class="viewcontent__footer">
                    <ul>
                        <li>Category:</li>
                        <li>SKU:</li>
                    </ul>
                    <ul>
                        <?php $__currentLoopData = $product->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($key->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($product->sku); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/frontend/productView.blade.php ENDPATH**/ ?>