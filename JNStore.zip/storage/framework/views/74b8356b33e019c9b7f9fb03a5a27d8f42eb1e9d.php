<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('icons/jn50.png')); ?>">
  <!-- loader-->
  <link href="<?php echo e(asset('admin/css/pace.min.css')); ?>" rel="stylesheet" />
  <script src="<?php echo e(asset('admin/js/pace.min.js')); ?>"></script>

  <!--plugins-->


  <link href="<?php echo e(asset('admin/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/notifications/css/lobibox.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/select2/css/select2-bootstrap4.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/plugins/input-tags/css/tagsinput.css')); ?>" rel="stylesheet" />


  <!-- CSS Files -->
  <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin/css/bootstrap-extended.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin/css/icons.css')); ?>" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

  <!--Theme Styles-->
  <link href="<?php echo e(asset('admin/css/dark-theme.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/css/semi-dark.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('admin/css/header-colors.css')); ?>" rel="stylesheet" />

   <?php echo $__env->yieldContent('styles'); ?>
  

  

  <title>Jn | Dashboard</title>
</head>
<body>
    <?php if(empty(Auth::user()->name)): ?>
        <div class="login-bg-overlay au-sign-in-basic"></div>
    <?php endif; ?>

    <div class="wrapper">
        <?php if(!empty(Auth::user()->name)): ?>
            <?php if(Auth::user()->is_admin == 1): ?>
                <?php echo $__env->make('layouts.parts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(Auth::user()->is_admin==0): ?>
                <?php echo $__env->make('layouts.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php else: ?>
            <?php echo $__env->make('layouts.parts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

  <!-- JS Files-->
  <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/bootstrap.bundle.min.js')); ?>"></script>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <!--plugins-->
  <script src="<?php echo e(asset('admin/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/chartjs/chart.min.js')); ?>"></script>

  <script src="<?php echo e(asset('admin/js/index.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/table-datatable.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/notifications/js/lobibox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/notifications/js/notifications.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/notifications/js/notification-custom-script.j')); ?>s"></script>
  <script src="<?php echo e(asset('admin/plugins/input-tags/js/tagsinput.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/form-select2.js')); ?>"></script>

  <!-- Main JS-->
  <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
 <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/layouts/app.blade.php ENDPATH**/ ?>