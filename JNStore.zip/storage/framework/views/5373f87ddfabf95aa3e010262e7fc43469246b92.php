<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>JN | Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('icons/jn50.png')); ?>">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/futura-std-font.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/meanmenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('customer/css/responsive.css')); ?>">
    <script src="https://js.stripe.com/v3/"></script>
</head>

<body>

    <?php echo $__env->make('frontend.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="hidden" id="modalShow" value="<?php echo e(session('modal')); ?>">
        <?php echo $__env->yieldContent('contant'); ?>
        <?php echo $__env->make('frontend.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('frontend.parts.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="checkOutDone" class="modal fade checkOutDone" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Order Status</h4>
                </div>
                <div class="modal-body">
                  <p>Your Order Successfully Submited</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>

            </div>
          </div>
    
    <script src="<?php echo e(asset('customer/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('customer/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/one-page-nav-min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/jquery.meanmenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/countdown.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/ajax-form.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customer/js/main.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
           $('.addToCart').click(function (e) {
                $.ajax({
                    url: $(this).attr("data-id"),
                    _method: 'GET',
                    success: function(respose) {
                        $(".cart__sidebar").load(location.href + " .cart__sidebar");
                        $('.counter').html();
                        $('.counter').html(respose);
                        // $('.cart__sidebar').addClass('open-cart');
                    }
                });
            });
        $(function () {
            let showModal = $('#modalShow').val();
            if (showModal) {
                alert('Order Success');
            }
        });
        function CartClose() {
           $('.cart__sidebar').removeClass('open-cart');
        }
        $('.view').on('click',function() {
            let pro = $('#productId').val();
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('index.getproduct')); ?>",
                data: {"id":pro ,"_token": "<?php echo e(csrf_token()); ?>"},
                success: function (response) {
                    $('.product-popup').html('')
                    $('.overlay,.product-popup').addClass('show-popup');
                        $('.product-popup').append(response)
                }
            });
        });
        function closePop() {
            $('.overlay,.product-popup').removeClass('show-popup');
        }
 </script>
</body>


<!-- Mirrored from themepure.net/template/gota/gota/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jan 2022 18:23:00 GMT -->
</html>
<?php echo $__env->yieldContent('styles'); ?>
<?php /**PATH C:\Users\amajad\Desktop\JNStore\resources\views/layouts/home.blade.php ENDPATH**/ ?>