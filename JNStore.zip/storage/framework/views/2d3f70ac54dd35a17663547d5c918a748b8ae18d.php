<form class="form-body categoryEditForm row g-3" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="col-12">
        <label class="form-lable">Name</label>
        <input type="text" name="name" id="editname" value="<?php echo e($category->name); ?>" required placeholder="Category Name" class="form-control">
    </div>
    <div class="col-12">
        <label class="form-lable">Slug</label>
        <input type="text" name="slug" id="editslug" required placeholder="" value="<?php echo e($category->slug); ?>" class="form-control">
    </div>
    <div class="col-12">
        <label class="form-lable">Add Icon Image</label>
        <input type="file" name="icon" id="icon" required class="form-control">

    </div>
    <div class="col-12">
        <img width="120px" src="<?php echo e(asset('CategoryIcon/'.$category->image)); ?>" alt="">
    </div>

    <div class="col">
        <button type="submit" class="btn categoryEditBtn btn-primary">
            Submit
        </button>
    </div>
</form>

<script>

$('#editname').change(function (e) {
        let name = $('#eidtname').val()
        let str = name.replace(/\s+/g, '-').toLowerCase();
        $('#editslug').val(str)
    });
    $('.categoryEditForm').submit(function (e) {
        e.preventDefault();
        let formData = new FormData($('.categoryEditForm')[0]);
       $.ajax({
            type: "POSt",
            url: "<?php echo e(route('catgeory.store')); ?>",
            data: formData,
            processData: false,
            contentType: false,
           success: function (response) {
            $('#Edit').modal('hide');
            success_noti(response)
           }
       });

    });
</script>

<?php /**PATH C:\Users\MiRzA\Desktop\JNStore\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>